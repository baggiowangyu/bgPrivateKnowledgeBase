package main

import (
	"github.com/gogf/gf/frame/g"
	_ "gmanager/boot"
)

func main() {
	g.Server().Run()
}
