package constants

// 调试日志配置
var DEBUG = true

const (
	CacheUserTokenPre = "API353_USER_TOKEN_"
	EnableYes         = 1
	UserTypeAdmin     = 1
)
